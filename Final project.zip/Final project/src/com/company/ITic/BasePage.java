package com.company.ITic;

import org.openqa.selenium.chrome.ChromeDriver;

public class BasePage {

    ChromeDriver driver;

}
